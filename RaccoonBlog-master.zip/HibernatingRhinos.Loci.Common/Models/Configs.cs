﻿namespace HibernatingRhinos.Loci.Common.Models
{
	public class Configs
	{
		public class ArrayContainer<T> { public T[] Items { get; set; } }
	}
}
