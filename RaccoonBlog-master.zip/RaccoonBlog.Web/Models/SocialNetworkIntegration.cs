﻿using System;
using System.Linq;
using System.Web;
using RaccoonBlog.Web.Models.SocialNetwork;

namespace RaccoonBlog.Web.Models
{
    public class SocialNetworkIntegration
    {
        public Reddit Reddit { get; set; }
    }
}