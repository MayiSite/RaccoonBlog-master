﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RaccoonBlog.Web.Areas.Admin.Enums
{
    public enum MenuButtonType
    {
        Plain,
        Add,
        Toggle
    }
}